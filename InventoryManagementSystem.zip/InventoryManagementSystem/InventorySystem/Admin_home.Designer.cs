﻿namespace InventorySystemCsharp
{
    partial class Admin_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_home));
            this.panel1 = new System.Windows.Forms.Panel();
            this.slide_panel = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.user_list_btn = new System.Windows.Forms.Button();
            this.add_manager_btn = new System.Windows.Forms.Button();
            this.dashboard_btn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dashboard_panel = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.check_orders_btn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.item_check_btn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.manager_home_btn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.user_home_btn = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.add_manager_panel = new System.Windows.Forms.Panel();
            this.typecomboTxt = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.Mregister_btn = new Bunifu.Framework.UI.BunifuFlatButton();
            this.MrepassTxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label12 = new System.Windows.Forms.Label();
            this.MpassTxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label13 = new System.Windows.Forms.Label();
            this.MphonenumTxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.MphoneTxt = new System.Windows.Forms.Label();
            this.MusernameTxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label11 = new System.Windows.Forms.Label();
            this.MlnameTxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label10 = new System.Windows.Forms.Label();
            this.MfnameTxt = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse3 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse4 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuElipse5 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.logout_btn = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.close_btn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.dashboard_panel.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.add_manager_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.slide_panel);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.user_list_btn);
            this.panel1.Controls.Add(this.add_manager_btn);
            this.panel1.Controls.Add(this.dashboard_btn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(277, 788);
            this.panel1.TabIndex = 0;
            // 
            // slide_panel
            // 
            this.slide_panel.BackColor = System.Drawing.Color.SeaGreen;
            this.slide_panel.Location = new System.Drawing.Point(0, 135);
            this.slide_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.slide_panel.Name = "slide_panel";
            this.slide_panel.Size = new System.Drawing.Size(20, 82);
            this.slide_panel.TabIndex = 3;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(27, 422);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(252, 82);
            this.button4.TabIndex = 6;
            this.button4.Text = "   Dashboard";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // user_list_btn
            // 
            this.user_list_btn.FlatAppearance.BorderSize = 0;
            this.user_list_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_list_btn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_list_btn.ForeColor = System.Drawing.Color.White;
            this.user_list_btn.Image = ((System.Drawing.Image)(resources.GetObject("user_list_btn.Image")));
            this.user_list_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user_list_btn.Location = new System.Drawing.Point(27, 327);
            this.user_list_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.user_list_btn.Name = "user_list_btn";
            this.user_list_btn.Size = new System.Drawing.Size(252, 82);
            this.user_list_btn.TabIndex = 5;
            this.user_list_btn.Text = "   Users List";
            this.user_list_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.user_list_btn.UseVisualStyleBackColor = true;
            this.user_list_btn.Click += new System.EventHandler(this.user_list_btn_Click);
            // 
            // add_manager_btn
            // 
            this.add_manager_btn.FlatAppearance.BorderSize = 0;
            this.add_manager_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_manager_btn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_manager_btn.ForeColor = System.Drawing.Color.White;
            this.add_manager_btn.Image = ((System.Drawing.Image)(resources.GetObject("add_manager_btn.Image")));
            this.add_manager_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.add_manager_btn.Location = new System.Drawing.Point(27, 231);
            this.add_manager_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_manager_btn.Name = "add_manager_btn";
            this.add_manager_btn.Size = new System.Drawing.Size(252, 82);
            this.add_manager_btn.TabIndex = 4;
            this.add_manager_btn.Text = "   Create Users";
            this.add_manager_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.add_manager_btn.UseVisualStyleBackColor = true;
            this.add_manager_btn.Click += new System.EventHandler(this.add_manager_btn_Click);
            // 
            // dashboard_btn
            // 
            this.dashboard_btn.FlatAppearance.BorderSize = 0;
            this.dashboard_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dashboard_btn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboard_btn.ForeColor = System.Drawing.Color.White;
            this.dashboard_btn.Image = ((System.Drawing.Image)(resources.GetObject("dashboard_btn.Image")));
            this.dashboard_btn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashboard_btn.Location = new System.Drawing.Point(27, 137);
            this.dashboard_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dashboard_btn.Name = "dashboard_btn";
            this.dashboard_btn.Size = new System.Drawing.Size(252, 82);
            this.dashboard_btn.TabIndex = 3;
            this.dashboard_btn.Text = "   Dashboard";
            this.dashboard_btn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.dashboard_btn.UseVisualStyleBackColor = true;
            this.dashboard_btn.Click += new System.EventHandler(this.dashboard_btn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(277, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1291, 28);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(168)))), ((int)(((byte)(20)))));
            this.panel3.Location = new System.Drawing.Point(107, 50);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(163, 212);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Location = new System.Drawing.Point(371, 11);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(163, 166);
            this.panel4.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(22, 132);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 3;
            this.label1.Text = "Hi Admin,";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(21, 14);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(121, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F);
            this.label2.Location = new System.Drawing.Point(540, 44);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(305, 42);
            this.label2.TabIndex = 3;
            this.label2.Text = "Inventory System";
            // 
            // dashboard_panel
            // 
            this.dashboard_panel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dashboard_panel.Controls.Add(this.panel5);
            this.dashboard_panel.Controls.Add(this.panel6);
            this.dashboard_panel.Controls.Add(this.panel8);
            this.dashboard_panel.Controls.Add(this.panel7);
            this.dashboard_panel.Controls.Add(this.label3);
            this.dashboard_panel.Location = new System.Drawing.Point(368, 201);
            this.dashboard_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dashboard_panel.Name = "dashboard_panel";
            this.dashboard_panel.Size = new System.Drawing.Size(1308, 593);
            this.dashboard_panel.TabIndex = 66;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(64)))), ((int)(((byte)(49)))));
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.check_orders_btn);
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Location = new System.Drawing.Point(936, 142);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(241, 272);
            this.panel5.TabIndex = 67;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(53, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 18);
            this.label7.TabIndex = 3;
            this.label7.Text = "Check Orders";
            // 
            // check_orders_btn
            // 
            this.check_orders_btn.ActiveBorderThickness = 1;
            this.check_orders_btn.ActiveCornerRadius = 20;
            this.check_orders_btn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.check_orders_btn.ActiveForecolor = System.Drawing.Color.White;
            this.check_orders_btn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.check_orders_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(64)))), ((int)(((byte)(49)))));
            this.check_orders_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("check_orders_btn.BackgroundImage")));
            this.check_orders_btn.ButtonText = "Orders";
            this.check_orders_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.check_orders_btn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_orders_btn.ForeColor = System.Drawing.Color.SeaGreen;
            this.check_orders_btn.IdleBorderThickness = 1;
            this.check_orders_btn.IdleCornerRadius = 20;
            this.check_orders_btn.IdleFillColor = System.Drawing.Color.White;
            this.check_orders_btn.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.check_orders_btn.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.check_orders_btn.Location = new System.Drawing.Point(24, 198);
            this.check_orders_btn.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.check_orders_btn.Name = "check_orders_btn";
            this.check_orders_btn.Size = new System.Drawing.Size(195, 57);
            this.check_orders_btn.TabIndex = 2;
            this.check_orders_btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.check_orders_btn.Click += new System.EventHandler(this.check_orders_btn_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(47, 22);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(148, 126);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(160)))), ((int)(((byte)(92)))));
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.item_check_btn);
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Location = new System.Drawing.Point(668, 142);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(241, 272);
            this.panel6.TabIndex = 67;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(59, 167);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Check Items";
            // 
            // item_check_btn
            // 
            this.item_check_btn.ActiveBorderThickness = 1;
            this.item_check_btn.ActiveCornerRadius = 20;
            this.item_check_btn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.item_check_btn.ActiveForecolor = System.Drawing.Color.White;
            this.item_check_btn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.item_check_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(160)))), ((int)(((byte)(92)))));
            this.item_check_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("item_check_btn.BackgroundImage")));
            this.item_check_btn.ButtonText = "Items";
            this.item_check_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.item_check_btn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item_check_btn.ForeColor = System.Drawing.Color.SeaGreen;
            this.item_check_btn.IdleBorderThickness = 1;
            this.item_check_btn.IdleCornerRadius = 20;
            this.item_check_btn.IdleFillColor = System.Drawing.Color.White;
            this.item_check_btn.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.item_check_btn.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.item_check_btn.Location = new System.Drawing.Point(23, 199);
            this.item_check_btn.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.item_check_btn.Name = "item_check_btn";
            this.item_check_btn.Size = new System.Drawing.Size(195, 57);
            this.item_check_btn.TabIndex = 2;
            this.item_check_btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.item_check_btn.Click += new System.EventHandler(this.item_check_btn_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(49, 21);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(147, 140);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(39)))), ((int)(((byte)(153)))));
            this.panel8.Controls.Add(this.label5);
            this.panel8.Controls.Add(this.manager_home_btn);
            this.panel8.Controls.Add(this.pictureBox3);
            this.panel8.Location = new System.Drawing.Point(400, 142);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(241, 272);
            this.panel8.TabIndex = 67;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(29, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(184, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "Check Manager Activity";
            // 
            // manager_home_btn
            // 
            this.manager_home_btn.ActiveBorderThickness = 1;
            this.manager_home_btn.ActiveCornerRadius = 20;
            this.manager_home_btn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.manager_home_btn.ActiveForecolor = System.Drawing.Color.White;
            this.manager_home_btn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.manager_home_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(39)))), ((int)(((byte)(153)))));
            this.manager_home_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("manager_home_btn.BackgroundImage")));
            this.manager_home_btn.ButtonText = "Manger Home";
            this.manager_home_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.manager_home_btn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manager_home_btn.ForeColor = System.Drawing.Color.SeaGreen;
            this.manager_home_btn.IdleBorderThickness = 1;
            this.manager_home_btn.IdleCornerRadius = 20;
            this.manager_home_btn.IdleFillColor = System.Drawing.Color.White;
            this.manager_home_btn.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.manager_home_btn.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.manager_home_btn.Location = new System.Drawing.Point(24, 198);
            this.manager_home_btn.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.manager_home_btn.Name = "manager_home_btn";
            this.manager_home_btn.Size = new System.Drawing.Size(195, 57);
            this.manager_home_btn.TabIndex = 2;
            this.manager_home_btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.manager_home_btn.Click += new System.EventHandler(this.manager_home_btn_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(47, 22);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(148, 126);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(161)))));
            this.panel7.Controls.Add(this.label4);
            this.panel7.Controls.Add(this.user_home_btn);
            this.panel7.Controls.Add(this.pictureBox2);
            this.panel7.Location = new System.Drawing.Point(132, 142);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(241, 272);
            this.panel7.TabIndex = 67;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(45, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "Check User Activity";
            // 
            // user_home_btn
            // 
            this.user_home_btn.ActiveBorderThickness = 1;
            this.user_home_btn.ActiveCornerRadius = 20;
            this.user_home_btn.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.user_home_btn.ActiveForecolor = System.Drawing.Color.White;
            this.user_home_btn.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.user_home_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(161)))));
            this.user_home_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("user_home_btn.BackgroundImage")));
            this.user_home_btn.ButtonText = "User Home";
            this.user_home_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.user_home_btn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_home_btn.ForeColor = System.Drawing.Color.SeaGreen;
            this.user_home_btn.IdleBorderThickness = 1;
            this.user_home_btn.IdleCornerRadius = 20;
            this.user_home_btn.IdleFillColor = System.Drawing.Color.White;
            this.user_home_btn.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.user_home_btn.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.user_home_btn.Location = new System.Drawing.Point(23, 199);
            this.user_home_btn.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.user_home_btn.Name = "user_home_btn";
            this.user_home_btn.Size = new System.Drawing.Size(195, 57);
            this.user_home_btn.TabIndex = 2;
            this.user_home_btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.user_home_btn.Click += new System.EventHandler(this.user_home_btn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(49, 21);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(147, 140);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(537, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(214, 27);
            this.label3.TabIndex = 3;
            this.label3.Text = "Admin Dashboard";
            // 
            // add_manager_panel
            // 
            this.add_manager_panel.Controls.Add(this.typecomboTxt);
            this.add_manager_panel.Controls.Add(this.label14);
            this.add_manager_panel.Controls.Add(this.Mregister_btn);
            this.add_manager_panel.Controls.Add(this.MrepassTxt);
            this.add_manager_panel.Controls.Add(this.label12);
            this.add_manager_panel.Controls.Add(this.MpassTxt);
            this.add_manager_panel.Controls.Add(this.label13);
            this.add_manager_panel.Controls.Add(this.MphonenumTxt);
            this.add_manager_panel.Controls.Add(this.MphoneTxt);
            this.add_manager_panel.Controls.Add(this.MusernameTxt);
            this.add_manager_panel.Controls.Add(this.label11);
            this.add_manager_panel.Controls.Add(this.MlnameTxt);
            this.add_manager_panel.Controls.Add(this.label10);
            this.add_manager_panel.Controls.Add(this.MfnameTxt);
            this.add_manager_panel.Controls.Add(this.label9);
            this.add_manager_panel.Controls.Add(this.label6);
            this.add_manager_panel.Location = new System.Drawing.Point(277, 201);
            this.add_manager_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.add_manager_panel.Name = "add_manager_panel";
            this.add_manager_panel.Size = new System.Drawing.Size(1308, 593);
            this.add_manager_panel.TabIndex = 67;
            // 
            // typecomboTxt
            // 
            this.typecomboTxt.FormattingEnabled = true;
            this.typecomboTxt.Items.AddRange(new object[] {
            "member",
            "manager"});
            this.typecomboTxt.Location = new System.Drawing.Point(652, 311);
            this.typecomboTxt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.typecomboTxt.Name = "typecomboTxt";
            this.typecomboTxt.Size = new System.Drawing.Size(344, 24);
            this.typecomboTxt.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(651, 276);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 21);
            this.label14.TabIndex = 18;
            this.label14.Text = "User Type";
            // 
            // Mregister_btn
            // 
            this.Mregister_btn.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Mregister_btn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Mregister_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Mregister_btn.BorderRadius = 7;
            this.Mregister_btn.ButtonText = "Create Account";
            this.Mregister_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Mregister_btn.DisabledColor = System.Drawing.Color.Gray;
            this.Mregister_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mregister_btn.Iconcolor = System.Drawing.Color.Transparent;
            this.Mregister_btn.Iconimage = ((System.Drawing.Image)(resources.GetObject("Mregister_btn.Iconimage")));
            this.Mregister_btn.Iconimage_right = null;
            this.Mregister_btn.Iconimage_right_Selected = null;
            this.Mregister_btn.Iconimage_Selected = null;
            this.Mregister_btn.IconMarginLeft = 0;
            this.Mregister_btn.IconMarginRight = 0;
            this.Mregister_btn.IconRightVisible = true;
            this.Mregister_btn.IconRightZoom = 0D;
            this.Mregister_btn.IconVisible = true;
            this.Mregister_btn.IconZoom = 90D;
            this.Mregister_btn.IsTab = false;
            this.Mregister_btn.Location = new System.Drawing.Point(633, 382);
            this.Mregister_btn.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Mregister_btn.Name = "Mregister_btn";
            this.Mregister_btn.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Mregister_btn.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.Mregister_btn.OnHoverTextColor = System.Drawing.Color.White;
            this.Mregister_btn.selected = false;
            this.Mregister_btn.Size = new System.Drawing.Size(399, 71);
            this.Mregister_btn.TabIndex = 17;
            this.Mregister_btn.Text = "Create Account";
            this.Mregister_btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Mregister_btn.Textcolor = System.Drawing.Color.White;
            this.Mregister_btn.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mregister_btn.Click += new System.EventHandler(this.Mregister_btn_Click);
            // 
            // MrepassTxt
            // 
            this.MrepassTxt.BackColor = System.Drawing.Color.White;
            this.MrepassTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MrepassTxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MrepassTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MrepassTxt.HintForeColor = System.Drawing.Color.Empty;
            this.MrepassTxt.HintText = "";
            this.MrepassTxt.isPassword = true;
            this.MrepassTxt.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MrepassTxt.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MrepassTxt.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MrepassTxt.LineThickness = 3;
            this.MrepassTxt.Location = new System.Drawing.Point(649, 212);
            this.MrepassTxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.MrepassTxt.Name = "MrepassTxt";
            this.MrepassTxt.Size = new System.Drawing.Size(347, 34);
            this.MrepassTxt.TabIndex = 16;
            this.MrepassTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(649, 177);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(186, 21);
            this.label12.TabIndex = 15;
            this.label12.Text = "Re-enter Password : ";
            // 
            // MpassTxt
            // 
            this.MpassTxt.BackColor = System.Drawing.Color.White;
            this.MpassTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MpassTxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MpassTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MpassTxt.HintForeColor = System.Drawing.Color.Empty;
            this.MpassTxt.HintText = "";
            this.MpassTxt.isPassword = true;
            this.MpassTxt.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MpassTxt.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MpassTxt.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MpassTxt.LineThickness = 3;
            this.MpassTxt.Location = new System.Drawing.Point(655, 122);
            this.MpassTxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.MpassTxt.Name = "MpassTxt";
            this.MpassTxt.Size = new System.Drawing.Size(347, 34);
            this.MpassTxt.TabIndex = 14;
            this.MpassTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(655, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 21);
            this.label13.TabIndex = 13;
            this.label13.Text = "Password : ";
            // 
            // MphonenumTxt
            // 
            this.MphonenumTxt.BackColor = System.Drawing.Color.White;
            this.MphonenumTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MphonenumTxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MphonenumTxt.ForeColor = System.Drawing.Color.Black;
            this.MphonenumTxt.HintForeColor = System.Drawing.Color.Empty;
            this.MphonenumTxt.HintText = "";
            this.MphonenumTxt.isPassword = false;
            this.MphonenumTxt.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MphonenumTxt.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MphonenumTxt.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MphonenumTxt.LineThickness = 3;
            this.MphonenumTxt.Location = new System.Drawing.Point(233, 388);
            this.MphonenumTxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.MphonenumTxt.Name = "MphonenumTxt";
            this.MphonenumTxt.Size = new System.Drawing.Size(327, 34);
            this.MphonenumTxt.TabIndex = 12;
            this.MphonenumTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // MphoneTxt
            // 
            this.MphoneTxt.AutoSize = true;
            this.MphoneTxt.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MphoneTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MphoneTxt.Location = new System.Drawing.Point(233, 352);
            this.MphoneTxt.Name = "MphoneTxt";
            this.MphoneTxt.Size = new System.Drawing.Size(157, 21);
            this.MphoneTxt.TabIndex = 11;
            this.MphoneTxt.Text = "Phone Number : ";
            // 
            // MusernameTxt
            // 
            this.MusernameTxt.BackColor = System.Drawing.Color.White;
            this.MusernameTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MusernameTxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MusernameTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MusernameTxt.HintForeColor = System.Drawing.Color.Empty;
            this.MusernameTxt.HintText = "";
            this.MusernameTxt.isPassword = false;
            this.MusernameTxt.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MusernameTxt.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MusernameTxt.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MusernameTxt.LineThickness = 3;
            this.MusernameTxt.Location = new System.Drawing.Point(233, 297);
            this.MusernameTxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.MusernameTxt.Name = "MusernameTxt";
            this.MusernameTxt.Size = new System.Drawing.Size(327, 34);
            this.MusernameTxt.TabIndex = 10;
            this.MusernameTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(233, 262);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 21);
            this.label11.TabIndex = 9;
            this.label11.Text = "User Name : ";
            // 
            // MlnameTxt
            // 
            this.MlnameTxt.BackColor = System.Drawing.Color.White;
            this.MlnameTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MlnameTxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MlnameTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MlnameTxt.HintForeColor = System.Drawing.Color.Empty;
            this.MlnameTxt.HintText = "";
            this.MlnameTxt.isPassword = false;
            this.MlnameTxt.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MlnameTxt.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MlnameTxt.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MlnameTxt.LineThickness = 3;
            this.MlnameTxt.Location = new System.Drawing.Point(233, 210);
            this.MlnameTxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.MlnameTxt.Name = "MlnameTxt";
            this.MlnameTxt.Size = new System.Drawing.Size(327, 34);
            this.MlnameTxt.TabIndex = 8;
            this.MlnameTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(233, 175);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 21);
            this.label10.TabIndex = 7;
            this.label10.Text = "Last Name : ";
            // 
            // MfnameTxt
            // 
            this.MfnameTxt.BackColor = System.Drawing.Color.White;
            this.MfnameTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MfnameTxt.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.MfnameTxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MfnameTxt.HintForeColor = System.Drawing.Color.Empty;
            this.MfnameTxt.HintText = "";
            this.MfnameTxt.isPassword = false;
            this.MfnameTxt.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MfnameTxt.LineIdleColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MfnameTxt.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(30)))), ((int)(((byte)(59)))));
            this.MfnameTxt.LineThickness = 3;
            this.MfnameTxt.Location = new System.Drawing.Point(236, 116);
            this.MfnameTxt.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.MfnameTxt.Name = "MfnameTxt";
            this.MfnameTxt.Size = new System.Drawing.Size(327, 34);
            this.MfnameTxt.TabIndex = 6;
            this.MfnameTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(233, 86);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 21);
            this.label9.TabIndex = 5;
            this.label9.Text = "Fisrt Name : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(537, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(256, 28);
            this.label6.TabIndex = 4;
            this.label6.Text = "Create New Account";
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 20;
            this.bunifuElipse1.TargetControl = this.panel7;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 20;
            this.bunifuElipse2.TargetControl = this.panel8;
            // 
            // bunifuElipse3
            // 
            this.bunifuElipse3.ElipseRadius = 20;
            this.bunifuElipse3.TargetControl = this.panel6;
            // 
            // bunifuElipse4
            // 
            this.bunifuElipse4.ElipseRadius = 20;
            this.bunifuElipse4.TargetControl = this.panel5;
            // 
            // bunifuElipse5
            // 
            this.bunifuElipse5.ElipseRadius = 35;
            this.bunifuElipse5.TargetControl = this;
            // 
            // logout_btn
            // 
            this.logout_btn.FlatAppearance.BorderSize = 0;
            this.logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout_btn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout_btn.ForeColor = System.Drawing.Color.White;
            this.logout_btn.Image = ((System.Drawing.Image)(resources.GetObject("logout_btn.Image")));
            this.logout_btn.Location = new System.Drawing.Point(1272, 32);
            this.logout_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(103, 71);
            this.logout_btn.TabIndex = 65;
            this.logout_btn.UseVisualStyleBackColor = true;
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // button9
            // 
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.Location = new System.Drawing.Point(1371, 32);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(93, 71);
            this.button9.TabIndex = 64;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // close_btn
            // 
            this.close_btn.FlatAppearance.BorderSize = 0;
            this.close_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_btn.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close_btn.ForeColor = System.Drawing.Color.White;
            this.close_btn.Image = ((System.Drawing.Image)(resources.GetObject("close_btn.Image")));
            this.close_btn.Location = new System.Drawing.Point(1469, 32);
            this.close_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.close_btn.Name = "close_btn";
            this.close_btn.Size = new System.Drawing.Size(85, 71);
            this.close_btn.TabIndex = 63;
            this.close_btn.UseVisualStyleBackColor = true;
            this.close_btn.Click += new System.EventHandler(this.close_btn_Click);
            // 
            // Admin_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1568, 788);
            this.Controls.Add(this.logout_btn);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.close_btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.add_manager_panel);
            this.Controls.Add(this.dashboard_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Admin_home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.dashboard_panel.ResumeLayout(false);
            this.dashboard_panel.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.add_manager_panel.ResumeLayout(false);
            this.add_manager_panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button dashboard_btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button user_list_btn;
        private System.Windows.Forms.Button add_manager_btn;
        private System.Windows.Forms.Panel slide_panel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button logout_btn;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button close_btn;
        private System.Windows.Forms.Panel dashboard_panel;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label5;
        private Bunifu.Framework.UI.BunifuThinButton2 manager_home_btn;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuThinButton2 user_home_btn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel add_manager_panel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.UI.BunifuThinButton2 check_orders_btn;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuThinButton2 item_check_btn;
        private System.Windows.Forms.PictureBox pictureBox5;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse3;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse4;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse5;
        private System.Windows.Forms.Label label9;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MphonenumTxt;
        private System.Windows.Forms.Label MphoneTxt;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MusernameTxt;
        private System.Windows.Forms.Label label11;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MlnameTxt;
        private System.Windows.Forms.Label label10;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MfnameTxt;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MpassTxt;
        private System.Windows.Forms.Label label13;
        private Bunifu.Framework.UI.BunifuMaterialTextbox MrepassTxt;
        private System.Windows.Forms.Label label12;
        private Bunifu.Framework.UI.BunifuFlatButton Mregister_btn;
        private System.Windows.Forms.ComboBox typecomboTxt;
        private System.Windows.Forms.Label label14;
    }
}